
declare module "format" {
    function format(fmt: string, ...args: any[]): void;
}
